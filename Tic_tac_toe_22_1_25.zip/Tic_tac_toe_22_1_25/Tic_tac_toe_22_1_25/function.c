
#define _CRT_SECURE_NO_WARNINGS 1;
#include"function.h"

void Initboard(char board[ROW][COL], int row, int col)
{
	int i = 0;
	int j = 0;
	for (i = 0; i < row ; i++)
	{
		for (j = 0; j < col; j++)
		{
			board[i][j] = ' ';
		}
	}

}



void Displayboard(char board[ROW][COL], int row, int col)
{
	int i = 0;
	int j = 0;
	for (i = 0; i < row; i++)
	{
		for (j = 0; j < col; j++)
		{
			printf("%c ", board[i][j]);
			if (j < col - 1)
				printf("|");
		}
		printf("\n");
		if (i < row - 1)
		{
			for (j = 0; j < col; j++)
			{
				printf("--");
				if (j < col - 1)
					printf("|");
			}
		}
		printf("\n");

		//printf(" %c| %c| %c \n", board[i][0], board[i][1], board[i][2]);
		//if (i<2)
		//	printf("--|--|--\n");
	}

}



void playermove(char board[ROW][COL], int row, int col)
{
	int a = 0;
	int b = 0;
	while (1)
	{
		printf("���������������:");
		scanf("%d %d", &a, &b);
		if (a > 0 && a <= 3 && b > 0 && b <= 3)
		{
			if (board[a-1][b-1] == ' ')
			{
				board[a-1][b-1] = '*';
				break;
			}
			else
				printf("�˸��ѱ�ռ������������\n");
				

		}
		else
			printf("������ֵ����ȷ������������\n");

	}


}


void copmove(char board[ROW][COL], int row, int col)
{
	int x = 0;
	int y = 0;
	srand((unsigned int)time(NULL));
	while (1)
	{
		x = rand() % 3;
		y = rand() % 3;
		if (board[x][y] == ' ')
		{
			board[x][y] = '#';
			break;
		}

	}


}


char Is_Win(char board[ROW][COL], int row, int col)
{
	int i = 0;
	int j = 0;
	while (1)
	{
		for (i = 0; i < row; i++)
		{
			if (board[i][0] == board[i][1] && board[i][1] == board[i][2] && board[i][0] != ' ')
			{
				return board[i][0];
				break;

			}

		}
		for (j = 0; j < col; j++)
		{
			if (board[0][j] == board[1][j] && board[1][j] == board[2][j] && board[0][j] != ' ')
			{
				return board[0][j];
				break;

			}
				
		}
		if (board[0][0] == board[1][1] && board[1][1] == board[2][2] && board[1][1] != ' ')
		{
			return board[0][0];
			break;
		}
		
		else if (board[2][0] == board[1][1] && board[1][1] == board[0][2] && board[1][1] != ' ')
		{
			return board[1][1];
			break;

		}
		else
		{
			for (i = 0; i < row; i++)
			{
				for (j = 0; j < col; j++)
				{
					if (board[i][j] == ' ')
						return 'R';
				}
			}
			return 'Q';
		}
		break;
			

	}





	
	
}

